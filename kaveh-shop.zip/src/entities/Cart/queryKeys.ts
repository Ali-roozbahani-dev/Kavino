

export const cartQueryKey = ["cart"];